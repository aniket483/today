package com.Assignment.SpringBootDay2;

import java.util.List;
import java.util.Optional;

public  interface BookStoreRepository {
	public void add_book(Book book);
	public void update_book(Book book,int book_id);
    public List <Book> findAll_book();
    public Optional<Book> findAll_book_id(int book_id);
    public void delete(int book_id);
    public Book findBookTitle(String book_title);


    public Book findByBookPublisherLike(String book_publisher);


    public Book findByYear(String book_year);

    

}
