package com.Assignment.SpringBootDay2;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface BookRepository extends JpaRepository<Book,Integer>{
	
	@Query("select b from Book_Details b where b.book_title=?1")
	public Book findBookTitle(String book_title);
	
	
//	@Query("select b from Book_Details b where b.book_publisher=?1")
	public Book findByBookPublisherLike(String book_publisher);
	
	
//	@Query("select b from Book_Details b where b.book_year=?1")
	public Book findByYear(String book_year);
	
	
}
