package com.Assignment.SpringBootDay2;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="book_details")
public class Book {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	String book_title;
	String book_publisher;
	String book_isbn;
	int book_number_of_pages;
	int book_year;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBook_title() {
		return book_title;
	}
	public void setBook_title(String book_title) {
		this.book_title = book_title;
	}
	public String getBook_publisher() {
		return book_publisher;
	}
	public void setBook_publisher(String book_publisher) {
		this.book_publisher = book_publisher;
	}
	public String getBook_isbn() {
		return book_isbn;
	}
	public void setBook_isbn(String book_isbn) {
		this.book_isbn = book_isbn;
	}
	public int getBook_number_of_pages() {
		return book_number_of_pages;
	}
	public void setBook_number_of_pages(int book_number_of_pages) {
		this.book_number_of_pages = book_number_of_pages;
	}
	public int getBook_year() {
		return book_year;
	}
	public void setBook_year(int book_year) {
		this.book_year = book_year;
	}
	@Override
	public String toString() {
		return "Book [id=" + id + ", book_title=" + book_title + ", book_publisher=" + book_publisher + ", book_isbn="
				+ book_isbn + ", book_number_of_pages=" + book_number_of_pages + ", book_year=" + book_year + "]";
	}
	public Book(int id, String book_title, String book_publisher, String book_isbn, int book_number_of_pages,
			int book_year) {
		super();
		this.id = id;
		this.book_title = book_title;
		this.book_publisher = book_publisher;
		this.book_isbn = book_isbn;
		this.book_number_of_pages = book_number_of_pages;
		this.book_year = book_year;
	}
	public Book() {
		super();
	}
	
	
	
}
