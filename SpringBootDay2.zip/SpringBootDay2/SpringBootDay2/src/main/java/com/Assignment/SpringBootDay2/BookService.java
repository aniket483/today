package com.Assignment.SpringBootDay2;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class BookService implements BookStoreRepository{

	@Autowired
	public BookRepository repo;
	
	@Override
	public void add_book(Book book) {
		repo.save(book)	;	
	}

	@Override
	public void update_book(Book book, int book_id) {
		repo.save(book);	
	}

	@Override
	public List<Book> findAll_book() {
		return repo.findAll();
	}

	@Override
	public Optional<Book> findAll_book_id(int book_id) {
		return repo.findById(book_id);

	}

	@Override
	public void delete(int book_id) {
		repo.deleteById(book_id);	
	}

	@Override
	public Book findBookTitle(String book_title) {
		return repo.findBookTitle(book_title);
	}

	@Override
	public Book findByBookPublisherLike(String book_publisher) {
		return repo.findByBookPublisherLike(book_publisher);
	}

	@Override
	public Book findByYear(String book_year) {
		return repo.findByYear(book_year);
	}

	
	
	
}
