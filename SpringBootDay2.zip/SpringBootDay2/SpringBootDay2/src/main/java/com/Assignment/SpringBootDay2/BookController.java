package com.Assignment.SpringBootDay2;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BookController {
	@Autowired
	private BookService bookservice;

	@RequestMapping(method = RequestMethod.POST, value = "/view_book")
	public void addBook(@RequestBody Book book) {
		bookservice.add_book(book);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/view_book/{bookid}")
	public void editBook(@RequestBody Book book, @PathVariable String bookid) {
		bookservice.update_book(book, Integer.parseInt(bookid));
	}

	@GetMapping("/view_book")
	public List<Book> getAllBook() {
		List<Book> allBookList = bookservice.findAll_book();
		return allBookList;
	}

	@GetMapping("/view_book/{bookid}")
	public Optional<Book> getBookById(@PathVariable String bookid) {
		Optional<Book> bookDetails = bookservice.findAll_book_id(Integer.parseInt(bookid));
		return bookDetails;
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/{bookid}")
	public void deleteBook(@RequestBody Book book, @PathVariable String bookid) {
		bookservice.delete(Integer.parseInt(bookid));
	}

}
